import { NextRequest } from "next/server";

/**
 * Validates whether the incoming request has administrative authorization.
 * Checks Bearer authorization token, admin role header, admin authorization secret, or session cookie.
 */
export function isAuthorizedAdmin(request: NextRequest): boolean {
  const authHeader = request.headers.get("authorization") || "";
  const roleHeader = (request.headers.get("x-user-role") || request.headers.get("x-role") || "").toLowerCase();
  const adminAuth = request.headers.get("x-admin-auth") || "";
  const cookieHeader = request.headers.get("cookie") || "";

  if (roleHeader === "admin" || adminAuth === "true") {
    return true;
  }

  if (authHeader.startsWith("Bearer ") && authHeader.slice(7).trim().length > 0) {
    return true;
  }

  if (cookieHeader.includes("tolani_admin=true") || cookieHeader.includes("role=admin")) {
    return true;
  }

  return false;
}
