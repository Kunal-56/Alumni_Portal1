import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;
    const folder = (formData.get("folder") as string) || "events";

    if (!file) {
      return NextResponse.json(
        { success: false, error: "No image file provided" },
        { status: 400 }
      );
    }

    // Allowed folders allowlist to prevent arbitrary directory creation / traversal
    const ALLOWED_FOLDERS = ["events", "gallery", "news", "avatars"];
    const requestedFolder = String(folder || "").trim().toLowerCase();
    const safeFolder = ALLOWED_FOLDERS.includes(requestedFolder) ? requestedFolder : "events";

    // Strict allowed image extensions to prevent arbitrary file upload and Stored XSS
    const ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif"];
    const rawExt = path.extname(file.name || "").toLowerCase();
    if (!rawExt || !ALLOWED_EXTENSIONS.includes(rawExt)) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid file extension. Only safe image files (JPG, PNG, WEBP, GIF, AVIF) are allowed. SVG and scripts are blocked.",
        },
        { status: 400 }
      );
    }

    // Validate safe image mime types (SVG deliberately excluded to prevent Stored XSS)
    const validMimes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/webp",
      "image/gif",
      "image/avif",
    ];

    if (!validMimes.includes(file.type.toLowerCase())) {
      return NextResponse.json(
        { success: false, error: "Invalid file type. Only standard raster image files (JPG, PNG, WEBP, GIF, AVIF) are allowed." },
        { status: 400 }
      );
    }

    // Max 15MB size limit
    const MAX_SIZE = 15 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { success: false, error: "Image file size exceeds the 15MB limit" },
        { status: 400 }
      );
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Target directory: public/uploads/<safeFolder> with path confinement check
    const uploadBaseDir = path.resolve(process.cwd(), "public", "uploads");
    const uploadDir = path.resolve(uploadBaseDir, safeFolder);
    if (!uploadDir.startsWith(uploadBaseDir)) {
      return NextResponse.json(
        { success: false, error: "Access denied: invalid upload directory path." },
        { status: 400 }
      );
    }

    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    // Generate safe, unique filename
    const originalExt = rawExt;
    const baseName = path
      .basename(file.name, originalExt)
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, "-")
      .slice(0, 30);
    const uniqueId = `${Date.now()}-${Math.round(Math.random() * 1e6)}`;
    const filename = `${baseName || "image"}-${uniqueId}${originalExt}`;
    const destinationPath = path.resolve(uploadDir, filename);

    // Ensure destination remains strictly confined within target uploadDir
    if (!destinationPath.startsWith(uploadDir)) {
      return NextResponse.json(
        { success: false, error: "Path traversal detected. Upload aborted." },
        { status: 400 }
      );
    }

    // Write file to disk
    fs.writeFileSync(destinationPath, buffer);

    // Public URL accessible by browser and stored in database
    const publicUrl = `/uploads/${safeFolder}/${filename}`;

    return NextResponse.json({
      success: true,
      url: publicUrl,
      filename,
      size: file.size,
      mimeType: file.type,
      message: "Local PC image successfully uploaded and stored on server",
    });
  } catch (error: any) {
    console.error("POST /api/upload error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to upload image file" },
      { status: 500 }
    );
  }
}

